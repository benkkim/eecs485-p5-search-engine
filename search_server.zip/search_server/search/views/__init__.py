"""initialization."""
from search.views.main import index